from django.db import models
from userinfo.models import *
from sale.models import *

ORDERSTATUS = (
  (0, '已出价'),
  (1, '已支付'),
  (2, '交易关闭'),
  (3, '订单关闭'),
  (4, '交易中'),
)

# Create your models here.

class Orders(models.Model):

  orderNo = models.CharField('订单号', max_length=50, null=False)
  buy_user = models.ForeignKey(UserInfo, related_name='buser')
  sale_user = models.ForeignKey(UserInfo, related_name='suser')
  car = models.CharField('车辆信息', max_length=200, null=False)

  price = models.DecimalField('价格', max_digits=8, decimal_places=2)

  date = models.DateTimeField('时间')
  orderStatus = models.IntegerField('订单状态', choices=ORDERSTATUS, default=0)

  isDelete = models.BooleanField('是否删除', default=False)

  def __str__(self):
    return self.orderNo

  class Meta:
    db_table = 'Orders'
    verbose_name = '订单表'
    verbose_name_plural = verbose_name



class Cart(models.Model):
  # 买家
  # 车辆id
  # 出价
  # 是否交易成功
  buser = models.ForeignKey(UserInfo)
  car = models.ForeignKey(CarInfo)
  price = models.DecimalField('出价', max_digits=8, decimal_places=2)

  def __str__(self):
    return '{0}-{1}'.format(self.buser.username, self.car.ctitle)

  class Meta:
    db_table = 'Cart'
    verbose_name = '出价意愿表'
    verbose_name_plural = verbose_name
