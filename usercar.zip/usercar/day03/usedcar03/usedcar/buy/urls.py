from django.conf.urls import url, include
from django.contrib import admin
from buy import views

urlpatterns = [
  url(r'showcart', views.show_cart, name='showcart'),
  url(r'addcart', views.add_cart, name='addcart'),
]