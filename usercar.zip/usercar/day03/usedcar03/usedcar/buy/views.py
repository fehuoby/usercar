from django.shortcuts import render, redirect
from .models import *
from django.db import DatabaseError
import logging
# Create your views here.

def show_cart(request):
  return render(request, 'cart.html')

def add_cart(request):
  # 1.判断用户是否登录
  # 2.获取用户, 车辆, 出价
  # 3.判断是否出价
  # 4.添加出价
  if request.user.is_authenticated():
    # 用户处于登录状态
    car_id = request.session.get('car_id')
    price = request.GET.get('price')
    cart = Cart.objects.filter(car_id=car_id, buser=request.user)
    if cart:
      # 已出价请勿重复出价
      # 已重新出价
      cartprice = cart[0].price
      price = float(price)
      if price == cartprice:
        return render(request, 'cart.html', {'car':"已出价请勿重复出价"})
      elif price != cartprice:
        cart.update(price=price)
        return render(request, 'cart.html', {'car':"已重新出价"})
    else:
      # 已添加出价
      try:
        car = CarInfo.objects.get(id=car_id)
        Cart.objects.create(buser = request.user, car=car, price=price)
      except DatabaseError as e:
        logging.warning(e)
      return render(request, 'cart.html', {'car':"已添加出价"})
  else:
    return redirect('/user/login/')
