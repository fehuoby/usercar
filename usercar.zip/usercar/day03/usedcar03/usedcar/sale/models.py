from django.db import models
from userinfo.models import UserInfo

# Create your models here.

EXAMINE = (
  (0, '审核中'),
  (1, '审核通过'),
  (2, '审核不通过'),
)

class Brand(models.Model):
  btitle = models.CharField(verbose_name='品牌名称', max_length=50, null=False)
  logo = models.ImageField(verbose_name='logo', upload_to='img/logo', default='')
  isDelete = models.BooleanField('是否删除',default=False)

  def __str__(self):
    return self.btitle

  class Meta:
    db_table = 'Brand'
    verbose_name = '品牌表'
    verbose_name_plural = verbose_name


class CarInfo(models.Model):
  serbran = models.ForeignKey(Brand)
  mileage = models.IntegerField('公里数', default=0)
  maintenance = models.BooleanField('维修记录', default=False)
  year = models.CharField('年份', max_length=20)
  color = models.CharField('颜色', max_length=30)
  picture = models.ImageField('图片', upload_to='img/car', default='')

  num = models.DecimalField('排量', max_digits=2, decimal_places=1)

  price = models.DecimalField('价格', max_digits=8, decimal_places=2)
  user = models.ForeignKey(UserInfo)

  isPurchase = models.BooleanField('是否购买', default=False)

  formalities = models.BooleanField('手续是否齐全', default=True)
  debt = models.BooleanField('是否有债务',default=False)

  regist = models.DateField('上牌日期', null=False)
  enginNo = models.CharField('发动机号', max_length=200, null=False)

  examine = models.IntegerField('审核进度', choices=EXAMINE, default=0)

  ctitle = models.CharField('车名', max_length=50, null=False)

  newprice = models.DecimalField('新车价格', max_digits=8, decimal_places=2)

  isDelete = models.BooleanField('是否删除', default=False)

  def __str__(self):
    return self.ctitle

  def get_absolute_url(self):
    return '/sale/detail?carid={}'.format(self.id)

  class Meta:
    db_table = 'Carinfo'
    verbose_name = '车辆信息表'
    verbose_name_plural = verbose_name




