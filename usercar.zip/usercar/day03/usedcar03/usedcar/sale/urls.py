from django.conf.urls import url, include
from django.contrib import admin
from sale import views

urlpatterns = [
    # url(r'detail/(\d+)/$', views.detail, name='detail'),
    url(r'detail', views.detail, name='detail'),
]