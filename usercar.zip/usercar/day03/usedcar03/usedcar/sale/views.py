from django.shortcuts import render
from .models import *
import random

# Create your views here.

def index(request):
  # 1.查询 没有被购买的以及未被删除的车辆
  # 2.调python的random()
  # 3.返回
  car_list = CarInfo.objects.filter(isPurchase=False, isDelete=False)
  car_four = random.sample(list(car_list), 4)
  return render(request, 'index.html', {'car_four':car_four})

def detail(request):
  # car_id = request.GET.get("car_id", "")
  # carinfo = CarInfo.objects.filter(id=car_id).first()
  # return render(request, 'detail.html', locals())

  car_id = request.GET.get("carid")
  carinfo = CarInfo.objects.filter(id=car_id).first()
  request.session['car_id'] = car_id
  return render(request, 'detail.html', locals())
