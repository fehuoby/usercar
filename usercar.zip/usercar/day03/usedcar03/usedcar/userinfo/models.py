from django.db import models
from django.contrib.auth.models import AbstractUser

SEX_CHOICES = (
  (1, '男'),
  (0, '女'),
)

BANDTYPE = (
  (0, '储蓄卡'),
  (1, '信用卡'),
)

BANKCHOICES = (
  (0, '中国银行'),
  (1, '中国建设银行'),
)

STATUS = (
  (0, '正常'),
  (1, '冻结'),
)

# Create your models here.

class UserInfo(AbstractUser):
  cellphone = models.CharField(max_length=11, null=True, blank=True, unique=True)
  uidentity = models.CharField('身份证', max_length=20, null=True, blank=True)
  address = models.CharField('地址', max_length=150, null=True, blank=True)
  sex = models.IntegerField('性别', choices=SEX_CHOICES, default=1)

  def __str__(self):
    return self.username

  class Meta:
    db_table = 'Users'
    verbose_name = '用户信息表'
    verbose_name_plural = verbose_name


class Band(models.Model):
  id

  cardNo = models.CharField('卡号', max_length=30, null=False)

  username = models.CharField('开户名', max_length=20, null=False)
  type = models.IntegerField('类型', choices=BANDTYPE, default=0)
  bank = models.IntegerField('开户行', choices=BANKCHOICES, default=0)
  cardStatus = models.IntegerField('状态', choices=STATUS, default=0)
  user = models.ForeignKey(UserInfo)

  def __str__(self):
    return self.username


class Message(models.Model):
  message = models.CharField('消息', max_length=200, null=False)
  user = models.ForeignKey(UserInfo)
  date = models.DateTimeField('时间', auto_now=True)

  def __str__(self):
    return self.message

  class Meta:
    db_table = 'Message'
    verbose_name = '消息表'
    verbose_name_plural = verbose_name

class Infomes(models.Model):
  sex = models.IntegerField('性别', choices=SEX_CHOICES, default=1)
  btitle = models.CharField('品牌名称', max_length=50, null=False)
  picture = models.ImageField('汽车图片', upload_to='img/car', default='')

  def __str__(self):
    return self.btitle

  class Meta:
    db_table = 'Infomes'
    verbose_name = '测试表'
    verbose_name_plural = verbose_name