from django.conf.urls import url, include
from django.contrib import admin
from userinfo import views

urlpatterns = [
    url(r'register/$', views.regiseter, name='register'),
    url(r'registerin/', views.regiseter_, name='register_in'),
    url(r'login/$', views.signin, name='login'),
    url(r'loginin/', views.login_, name='login_in'),
    url(r'logout/$', views.logout_, name='logout'),
    url(r'^infomes/$', views.infomes, name='infomes'),
    url(r'infomesin/', views.infomes_, name='infomes_in')
]