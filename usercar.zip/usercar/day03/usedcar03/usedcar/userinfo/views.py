from django.shortcuts import render, redirect
from .models import *
from django.contrib.auth.hashers import make_password, check_password
from django.db import DatabaseError
import logging
from django.contrib.auth import authenticate, login, logout

# Create your views here.

def regiseter(request):
  return render(request, 'register.html')

def regiseter_(request):
  # 1.判断是否post方法
  # 2.获取用户,密码
  # 3.判断用户是否存在
  # 4.判断两次密码是否一致
  # 5.将用户注册(加密注册)
  # 6.返回
  if request.method == 'POST':
    username = request.POST.get('username', '')
    password = request.POST.get('password', '')
    cpassword = request.POST.get('cpassword', '')
    if username and password and cpassword:
      olduser = UserInfo.objects.filter(username=username)
      if olduser:
        return render(request, 'register.html', {'msg':"该用户已经存在"})
      if password != cpassword:
        return render(request, 'register.html', {"msg":"两次密码不一致"})
      newpassword = make_password(password, None, 'pbkdf2_sha1')
      # 参1:加密的密码, 参2:任意的字符串 参3:加密方式
      # 得到的是一串随机的字符串,并且每次生成都不一样
      try:
        UserInfo.objects.create(username=username, password=newpassword)
      except DatabaseError as e:
        logging.warning(e)
      return render(request, 'register.html', {'msg':"注册成功"})
    else:
      return render(request, 'register.html', {'msg':"输入项不能为空"})


def signin(request):
  return render(request, 'login.html')

def login_(request):
  # 1.判断传递方式
  # 2.获取用户，密码
  # 3.判断用户是否注册
  #   查数据库
  # 4.解密,判断密码是否正确
  # 5.存session/使用django自带的登录　login()
  if request.method == 'POST':
    username = request.POST.get('username', '')
    password = request.POST.get('password', '')
    if username and password:
      user = UserInfo.objects.filter(username=username)
      # if not user:
      #   return render(request, 'login.html', {'msg':'该用户为注册'})
      # check_password(明文, 密文)
      # 使用django提供的验证方法,传入用户名和密码,会返回一个user对象
      user = authenticate(username=username, password=password)
      if user is not None and user.is_active:
        # 登录
        login(request, user)
        # return render(request, 'login.html', {'msg':"登录成功"})
        return redirect('/')
      else:
        return render(request, 'login.html', {'msg':'用户名或密码错误'})

    else:
      return render(request, 'login.html', {'msg':"输入项不能为空"})

def logout_(request):
  logout(request)
  return redirect('/')


def infomes(request):
  return render(request, 'info-message.html')

from django.http import HttpResponse

def infomes_(request):
  if request.method == 'POST':
    sex = request.POST.get("gender")
    btitle = request.POST.get("brands")
    picture = request.FILES.get("pic")
    print(sex, btitle, picture)
    inf = Infomes()
    inf.sex = sex
    inf.btitle = btitle
    inf.picture = picture
    try:
      inf.save()
    except DatabaseError as e:
      logging.warning(e)
    return HttpResponse('ok')
    # return HttpResponse(json.dumps({"result":"", "data":"", "error":""}))