# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo01_fill.py  填充图
"""
import numpy as np
import matplotlib.pyplot as mp

# 生成数据
n = 1000
x = np.linspace(0, 8 * np.pi, n)
sinx = np.sin(x)
cosx = np.cos(x / 2) / 2

mp.figure('Fill', facecolor='lightgray')
mp.title('Fill', fontsize=16)
mp.xlabel('X', fontsize=12)
mp.ylabel('Y', fontsize=12)
mp.tick_params(labelsize=10)
mp.plot(x, sinx, color='dodgerblue',
        label=r'$y=sin(x)$')
mp.plot(x, cosx, color='orangered',
        label=r'$y=\frac{1}{2}cos(\frac{x}{2})$')
# 设置填充
mp.fill_between(x, sinx, cosx, sinx > cosx,
                color='dodgerblue', alpha=0.6)
mp.fill_between(x, sinx, cosx, sinx < cosx,
                color='orangered', alpha=0.6)

mp.legend()
mp.show()
