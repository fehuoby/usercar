# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo02_bar.py  条形图
"""
import numpy as np
import matplotlib.pyplot as mp

# 生成数据
apples = np.array([64, 56, 85, 79, 17, 45, 68, 94, 36, 58, 34, 91])
oranges = np.array([96, 58, 34, 58, 29, 34, 56, 23, 94, 56, 23, 56])

# 绘制图像
mp.figure('Bar', facecolor='lightgray')
mp.title('Bar', fontsize=16)
mp.xlabel('Month', fontsize=12)
mp.ylabel('Sells', fontsize=12)
mp.tick_params(labelsize=10)
x = np.arange(apples.size)
mp.bar(x - 0.2, apples, 0.4, color='dodgerblue',
       label='Apples', align='center')
mp.bar(x + 0.2, oranges, 0.4, color='orangered',
       label='Oranges')
mp.xticks(x, ['Jan', 'Feb', 'Mar', 'Apr', 'May',
              'Jun', 'Jul', 'Aug', 'Sep', 'Oct',
              'Nov', 'Dec'])
mp.legend()
mp.show()
