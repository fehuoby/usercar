# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo04_contour.py  绘制等高线
"""
import numpy as np
import matplotlib.pyplot as mp

# 整理数据
n = 1000
# x与y：从-3~3拆1000个点
x, y = np.meshgrid(np.linspace(-3, 3, n),
                   np.linspace(-3, 3, n))
# 通过一个数学公式计算每个网格点的高度
z = (1 - x / 2 + x**5 + y**3) * \
    np.exp(-x**2 - y**2)

# 绘制图形
mp.figure('Contour', facecolor='lightgray')
mp.title('Contour', fontsize=14)
mp.xlabel('x', fontsize=12)
mp.ylabel('y', fontsize=12)
mp.tick_params(labelsize=10)
mp.grid(linestyle=':')
# 绘制等高线图
cntr = mp.contour(x, y, z, 8, colors='black',
                  linewidths=0.5)
# 为等高线添加高度值标签文本
mp.clabel(cntr, inline_spacing=1, fmt='%.1f',
          fontsize=10)
# 为等高线图绘制填充色
mp.contourf(x, y, z, 8, cmap='jet')
mp.show()
