# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo07_wireframe.py  绘制3D线框图
"""
import numpy as np
import matplotlib.pyplot as mp
from mpl_toolkits.mplot3d import axes3d
# 整理数据
n = 1000
# x与y：从-3~3拆1000个点
x, y = np.meshgrid(np.linspace(-3, 3, n),
                   np.linspace(-3, 3, n))
# 通过一个数学公式计算每个网格点的高度
z = (1 - x / 2 + x**5 + y**3) * \
    np.exp(-x**2 - y**2)

# 绘制图形
mp.figure('3D Surface', facecolor='lightgray')
ax3d = mp.gca(projection='3d')
ax3d.set_xlabel('x', fontsize=12)
ax3d.set_ylabel('y', fontsize=12)
ax3d.set_zlabel('z', fontsize=12)
ax3d.plot_surface(
    x, y, z, rstride=1, cstride=1, cmap='jet')
mp.tight_layout()
mp.show()
