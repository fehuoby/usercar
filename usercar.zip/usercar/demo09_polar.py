# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo09_polar.py  极坐标系
"""
import numpy as np
import matplotlib.pyplot as mp

mp.figure('Polar')
mp.gca(projection='polar')
mp.title('Polar')
mp.xlabel(r'$\theta$', fontsize=12)
mp.ylabel(r'$\rho$', fontsize=12)
mp.tick_params(labelsize=10)
mp.grid(linestyle=':')
# 绘制曲线
t = np.linspace(0, 4 * np.pi, 1000)
r = 0.8 * t
mp.plot(t, r)
mp.tight_layout()
mp.show()
