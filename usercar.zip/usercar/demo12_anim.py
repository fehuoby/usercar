# -*- coding: utf-8 -*-
from __future__ import unicode_literals
"""
demo12_anim.py  带有生成器函数的简单动画
"""
import numpy as np
import matplotlib.pyplot as mp
import matplotlib.animation as ma

mp.figure('Signal', facecolor='lightgray')
mp.title('Signal', fontsize=14)
mp.xlim(0, 10)
mp.ylim(-3, 3)
mp.grid(linestyle=':')
pl = mp.plot([], [], color='dodgerblue',
             label='Signal')[0]

x = 0


def update(data):
    t, v = data
    x, y = pl.get_data()
    x = np.append(x, t)  # x末尾追加t
    y = np.append(y, v)  # y末尾追加v
    pl.set_data(x, y)
    # 移动坐标轴
    if(x[-1] > 10):
        mp.xlim(x[-1] - 10, x[-1])


def generator():
    # 通过x  计算y， 作为一组新数据交给update
    global x
    y = np.sin(2 * np.pi * x) * \
        np.exp(np.sin(0.2 * np.pi * x))
    yield (x, y)
    x += 0.05

# 基于动画动态绘制图像
anim = ma.FuncAnimation(
    mp.gcf(), update, generator, interval=30)

mp.tight_layout()
mp.legend()
mp.show()
